2026-12-25 16:27:18 [WARN]  High memory usage detected: 54% on node 7
2026-11-02 03:18:24 [WARN]  Disk usage at 66% on /var/log partition
2026-07-23 05:33:05 [ERROR] Failed login attempt for user 'admin' from 33.78.189.198
2026-05-27 18:41:24 [ERROR] Failed login attempt for user 'admin' from 116.84.217.109
2026-01-04 21:58:38 [INFO]  Backup completed: 357MB written to /backups/snap_1777188773
2026-09-17 00:57:21 [ERROR] Connection timeout to db-replica-26 after 2738ms
2026-12-17 19:12:43 [INFO]  Backup completed: 1318MB written to /backups/snap_1777024583
2026-02-21 16:46:38 [ERROR] Failed login attempt for user 'msmith' from 77.246.241.122
2026-12-13 19:15:40 [DEBUG] Cache miss for key user_session_f2df60808e43
2026-07-23 09:29:46 [INFO]  Backup completed: 1059MB written to /backups/snap_1776825424
2026-10-22 18:47:01 [WARN]  Disk usage at 75% on /var/log partition
2026-05-04 21:54:41 [DEBUG] Cache miss for key user_session_8a8eb32326bf
2026-08-20 22:02:41 [INFO]  Request from 59.20.23.89 - GET /api/v4/status - 200 OK
2026-06-28 00:34:03 [ERROR] Failed login attempt for user 'svc_backup' from 128.96.109.205
2026-09-20 00:16:11 [INFO]  Scheduled job 'cleanup_tmp' completed in 650ms
2026-05-14 08:25:04 [DEBUG] Cache miss for key user_session_ab9fcb253585
2026-11-16 21:08:18 [WARN]  Disk usage at 73% on /var/log partition
2026-12-22 18:19:20 [ERROR] Failed login attempt for user 'root' from 127.46.128.246
2026-07-04 11:38:03 [INFO]  Scheduled job 'cleanup_tmp' completed in 4461ms
2026-01-27 16:33:25 [INFO]  Backup completed: 1321MB written to /backups/snap_1777315217
2026-10-24 06:04:34 [INFO]  Request from 19.85.3.131 - GET /api/v1/status - 200 OK
2026-01-03 14:37:14 [INFO]  Request from 140.204.232.106 - GET /api/v2/status - 200 OK
2026-05-23 17:42:29 [INFO]  Backup completed: 2222MB written to /backups/snap_1776883354
2026-01-14 10:51:44 [INFO]  Backup completed: 166MB written to /backups/snap_1777057165
2026-12-17 11:42:16 [DEBUG] Cache miss for key user_session_ac32eaadd552
2026-05-21 18:03:35 [WARN]  High memory usage detected: 91% on node 2
[TOKEN] fl@g{nope}
[TOKEN] CodeandCapture{vpsxoyk qshvwtf aijggwe ygvgarc bpaffta aaztoii extra}
[TOKEN] CodeandCapture{this-has-hyphens-instead-of-underscores-fail}
[TOKEN] CodeandCapture{sha256:e3b0c44298fc1c149afbf4c8996fb924}

Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.
Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum.
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
Curabitur pretium tincidunt lacus. Nulla gravida orci a odio. Nullam varius, turpis molestie dictum semper.
[TOKEN] codeandcapture{all_lowercase_prefix_is_wrong_here}
[TOKEN] CodeandCapture{wvjghbu bttnlwy objjwof lacuwhd wufhdas sbvwmrt extra}

2026-09-15 20:29:46 [WARN]  Disk usage at 87% on /var/log partition
2026-04-06 18:10:43 [ERROR] Failed login attempt for user 'msmith' from 39.143.161.226
2026-10-13 19:34:58 [INFO]  Scheduled job 'cleanup_tmp' completed in 8819ms
2026-03-14 21:10:17 [INFO]  Scheduled job 'cleanup_tmp' completed in 2552ms
2026-01-04 11:39:02 [INFO]  Scheduled job 'cleanup_tmp' completed in 1149ms
2026-08-23 21:27:23 [INFO]  Request from 77.40.238.146 - GET /api/v1/status - 200 OK
2026-11-25 10:41:41 [INFO]  Scheduled job 'cleanup_tmp' completed in 1665ms
2026-10-19 14:57:39 [ERROR] Failed login attempt for user 'svc_backup' from 102.6.19.216
2026-11-13 03:11:00 [WARN]  Disk usage at 50% on /var/log partition
2026-06-26 04:43:26 [INFO]  Request from 42.133.44.83 - GET /api/v1/status - 200 OK
2026-10-10 20:21:51 [ERROR] Connection timeout to db-replica-18 after 5361ms
2026-04-13 16:46:09 [ERROR] Failed login attempt for user 'root' from 66.225.128.245
2026-12-27 19:14:42 [WARN]  High memory usage detected: 84% on node 7
2026-03-15 07:24:41 [INFO]  Scheduled job 'cleanup_tmp' completed in 5999ms
2026-05-11 22:34:27 [WARN]  Disk usage at 75% on /var/log partition
2026-09-26 03:18:09 [WARN]  High memory usage detected: 71% on node 3
2026-01-18 22:14:36 [INFO]  Request from 131.164.210.173 - GET /api/v3/status - 200 OK
2026-08-01 09:13:04 [WARN]  High memory usage detected: 61% on node 8
2026-07-03 04:27:21 [WARN]  Disk usage at 75% on /var/log partition
2026-11-09 13:55:05 [ERROR] Failed login attempt for user 'svc_backup' from 116.96.119.7
2026-07-11 02:45:15 [INFO]  Scheduled job 'cleanup_tmp' completed in 5071ms
2026-01-22 01:55:45 [INFO]  Scheduled job 'cleanup_tmp' completed in 5587ms
2026-04-22 21:44:28 [WARN]  High memory usage detected: 89% on node 4
2026-05-28 15:18:37 [ERROR] Failed login attempt for user 'jdoe' from 105.26.225.140
2026-02-01 15:24:09 [INFO]  Request from 48.219.50.114 - GET /api/v1/status - 200 OK
2026-08-07 00:56:26 [ERROR] Failed login attempt for user 'root' from 112.133.243.8
[TOKEN] CodeandCapture{token_93197EAE462A20B0_1773402474_EXP}
[TOKEN] Codeandcapture{not_real_73094fc5}
[TOKEN] CodeandCapture{ojpkzdxbotdtbos@awbrqqdqth#3d7c29e4}

38 c7 42 d0 7d 83 97 9b cb 93 02 f3 18 b7 8a 02 b5 33 db 8e a3 d7 ff 41 fc c7 e0 37 ee 91 fa 75 ea db eb be 2b 75 29 ea 78 30 b2 37 93 93 f8 46 94 d2 3c 72 f5 b3 0a 3e e3 a3 ce 34 4e 34 cc 86 f3 7a 02 d8 fd 14 5f 22 9a 0f ce ee 47 a9 d5 2d 50 27 80 3d fd 5a bb 5d f5 3e 16 14 cd 44 37 f3 3d fd bc d7 5b 29 a9 70 17 c4 0f
[TOKEN] CodeAndCapture{access_code_befe9d25}
[TOKEN] CodeandCapture{bpmyixzhsrzvepbkmcvc_QXGYXTTRGI_1fe26e2b}
[TOKEN] CodeandCapture{yiobmmor-wkwqauds-snaslspt-czjxtcmk-ljevrwzy-vpeocdub}
[TOKEN] CodeandCapture{this-has-hyphens-instead-of-underscores-fail}

{
  "oftfm": "cb81c33e87df68b9",
  "hulyfw": 9021,
  "pynp": "fvyxcybh",
  "ts": 1702335530
}
[TOKEN] CodeandCapture{unulzyjzmgldfxgnyhad_CZMRIJTTRP_5d81fe76}

SELECT u.id, u.email, r.name FROM users u JOIN roles r ON u.role_id = r.id WHERE u.active = 1 LIMIT 100;

[TOKEN] flag{short}

db_host = db-primary-13.internal
db_port = 5432
db_name = app_dev
max_connections = 100
[TOKEN] CodeandCapture{ngpip_32f48e}
[TOKEN] CodeandCapture{jycvzea plqvxyu rdcoqmu lxmuiaf rhuqckt sauxxdb extra}
[TOKEN] CodeandCapture{ridmyprbmrazhsnlumqd_QUHHVZBYMI_5766d6f8}
[TOKEN] CodeandCapture{jjktqnkbcctavnf@vshnhgafnl#fc230dc8}
