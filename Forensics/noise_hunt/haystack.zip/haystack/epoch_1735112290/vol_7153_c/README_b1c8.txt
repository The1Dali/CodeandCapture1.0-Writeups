SELECT u.id, u.email, r.name FROM users u JOIN roles r ON u.role_id = r.id WHERE u.active = 1 LIMIT 100;

[TOKEN] CodeandCapture{this has spaces in it and is way too long oops}

{
  "aahje": "f2dfced9f91f7383",
  "ommzcv": 5209,
  "evlb": "iwpzbmtn",
  "ts": 1713859818
}
[TOKEN] CodeandCapture{vetptim pypcxjo vtslujg apwqhfd cmcfxbz ymzcnzg extra}
[TOKEN] CodeandCapture{wqutgngs-bjtloyne-kagfxeme-ujglcwvi-lilientq-esrgrpug}

2026-08-02 22:38:31 [INFO]  Backup completed: 1894MB written to /backups/snap_1776982301
2026-02-25 19:48:53 [INFO]  Backup completed: 1918MB written to /backups/snap_1776895987
2026-01-17 11:54:09 [INFO]  Request from 19.205.237.157 - GET /api/v4/status - 200 OK
2026-05-22 23:32:38 [INFO]  Request from 104.54.246.103 - GET /api/v3/status - 200 OK
2026-06-17 19:11:42 [ERROR] Failed login attempt for user 'msmith' from 64.19.95.1
2026-12-25 00:27:43 [INFO]  Scheduled job 'cleanup_tmp' completed in 5759ms
2026-06-23 04:38:27 [ERROR] Failed login attempt for user 'jdoe' from 93.96.77.50
2026-10-06 16:49:44 [WARN]  High memory usage detected: 86% on node 14
2026-10-12 07:15:09 [ERROR] Connection timeout to db-replica-23 after 457ms
2026-09-15 20:29:52 [WARN]  High memory usage detected: 72% on node 14
2026-12-16 01:19:35 [WARN]  High memory usage detected: 87% on node 12
2026-12-20 08:28:56 [DEBUG] Cache miss for key user_session_034a40043c8d
2026-05-19 20:35:49 [INFO]  Request from 71.152.67.59 - GET /api/v3/status - 200 OK
2026-06-04 20:09:26 [DEBUG] Cache miss for key user_session_78e726e7c5d0
2026-09-02 22:03:17 [DEBUG] Cache miss for key user_session_217c4fdb3f92
2026-08-11 15:31:02 [INFO]  Backup completed: 3441MB written to /backups/snap_1777336426
2026-12-19 13:17:38 [DEBUG] Cache miss for key user_session_3d78567cfb11
2026-09-25 08:32:15 [INFO]  Request from 14.23.210.123 - GET /api/v3/status - 200 OK
2026-07-08 16:02:33 [INFO]  Scheduled job 'cleanup_tmp' completed in 5561ms
2026-01-27 01:43:23 [WARN]  High memory usage detected: 66% on node 13
2026-07-08 23:11:36 [WARN]  High memory usage detected: 86% on node 7
2026-08-18 02:07:20 [DEBUG] Cache miss for key user_session_0c6533513d15
2026-06-26 23:48:08 [WARN]  High memory usage detected: 56% on node 13
2026-02-21 23:57:14 [INFO]  Request from 17.48.154.96 - GET /api/v3/status - 200 OK
2026-06-18 05:51:09 [INFO]  Scheduled job 'cleanup_tmp' completed in 761ms
2026-08-10 03:29:48 [WARN]  High memory usage detected: 88% on node 14
2026-04-21 04:43:36 [INFO]  Request from 134.115.148.75 - GET /api/v3/status - 200 OK
2026-05-08 11:27:09 [INFO]  Scheduled job 'cleanup_tmp' completed in 115ms
2026-12-06 05:29:27 [WARN]  High memory usage detected: 88% on node 7
[TOKEN] CodeAndCapture{wrong_case_in_the_middle_prefix}
[TOKEN] CodeandCapture{yiobmmor-wkwqauds-snaslspt-czjxtcmk-ljevrwzy-vpeocdub}

2026-11-02 19:44:44 [ERROR] Failed login attempt for user 'admin' from 15.12.219.158
2026-03-06 14:58:05 [ERROR] Connection timeout to db-replica-25 after 2271ms
2026-10-21 09:05:25 [INFO]  Backup completed: 1685MB written to /backups/snap_1776913636
2026-06-24 17:39:25 [WARN]  Disk usage at 59% on /var/log partition
2026-01-19 14:19:43 [WARN]  Disk usage at 97% on /var/log partition
2026-02-19 19:44:23 [WARN]  Disk usage at 65% on /var/log partition
2026-08-17 14:04:52 [WARN]  Disk usage at 54% on /var/log partition
2026-11-22 09:44:22 [ERROR] Failed login attempt for user 'admin' from 34.220.179.223
2026-06-04 02:26:26 [INFO]  Scheduled job 'cleanup_tmp' completed in 829ms
2026-06-21 18:08:06 [ERROR] Connection timeout to db-replica-22 after 3114ms
2026-04-16 15:55:39 [WARN]  Disk usage at 74% on /var/log partition
2026-04-11 00:26:05 [WARN]  Disk usage at 56% on /var/log partition
2026-10-08 01:45:45 [ERROR] Connection timeout to db-replica-22 after 6066ms
2026-11-09 13:24:10 [INFO]  Backup completed: 2659MB written to /backups/snap_1777142268
2026-03-28 01:13:23 [WARN]  High memory usage detected: 93% on node 14
2026-06-08 09:32:06 [DEBUG] Cache miss for key user_session_065e4d16b15c
2026-12-16 22:35:46 [WARN]  Disk usage at 73% on /var/log partition
2026-12-18 21:51:34 [INFO]  Backup completed: 3126MB written to /backups/snap_1777500481
2026-01-11 14:45:08 [ERROR] Connection timeout to db-replica-15 after 8058ms
2026-08-20 23:39:16 [INFO]  Scheduled job 'cleanup_tmp' completed in 8670ms
2026-03-14 21:20:39 [WARN]  Disk usage at 54% on /var/log partition
2026-03-24 14:58:55 [WARN]  High memory usage detected: 80% on node 8
2026-04-05 14:41:49 [ERROR] Connection timeout to db-replica-9 after 6551ms
[TOKEN] CodeandCapture{jjktqnkbcctavnf@vshnhgafnl#fc230dc8}
[TOKEN] CodeandCapture{osrclmkqdzmakbdmsjsp_VJZZWLPPXP_392209a8}

api_endpoint = https://internal-api-9.corp/v1
api_timeout = 26s
retry_limit = 1
[TOKEN] CodeandCapture{qmxohgfuvouddirltqou_NIZDKEIQBI_d5a1b593}
[TOKEN] CodeandCapture{b64:OozRVZiESQUBNUQ9aGDpb2tntUE=}

2026-09-08 06:06:27 [INFO]  Scheduled job 'cleanup_tmp' completed in 7311ms
2026-10-18 09:42:41 [DEBUG] Cache miss for key user_session_effc73311f89
2026-01-21 04:05:41 [ERROR] Connection timeout to db-replica-3 after 6845ms
2026-03-27 01:03:06 [INFO]  Scheduled job 'cleanup_tmp' completed in 1453ms
2026-04-15 02:43:03 [ERROR] Failed login attempt for user 'root' from 125.108.161.155
2026-01-17 16:16:15 [INFO]  Scheduled job 'cleanup_tmp' completed in 6800ms
2026-10-25 22:51:35 [ERROR] Failed login attempt for user 'jdoe' from 172.0.143.155
2026-10-04 11:04:23 [WARN]  High memory usage detected: 77% on node 2
2026-10-27 18:22:26 [ERROR] Failed login attempt for user 'admin' from 141.52.16.240
2026-02-03 14:32:08 [INFO]  Request from 127.40.182.237 - GET /api/v4/status - 200 OK
2026-05-23 13:17:35 [INFO]  Request from 43.29.200.146 - GET /api/v1/status - 200 OK
2026-02-07 07:58:47 [INFO]  Scheduled job 'cleanup_tmp' completed in 5016ms
2026-01-15 17:27:34 [INFO]  Request from 166.151.252.19 - GET /api/v1/status - 200 OK
2026-02-10 01:01:10 [ERROR] Connection timeout to db-replica-12 after 7550ms
[TOKEN] CodeandCapture{nuupxzqozkyypqy@gtvoxngguz#18ecbcff}
[TOKEN] CodeandCapture{jtcfmxl ruarwmy uncapnm egqiuba mlysgub aivifae extra}
[TOKEN] flag{invalid@symbol}
[TOKEN] CodeandCapture{zaebjnyrfcpipu_655631}

2026-01-26 16:37:30 [ERROR] Failed login attempt for user 'svc_backup' from 39.6.23.39
2026-01-19 04:11:43 [WARN]  Disk usage at 67% on /var/log partition
2026-07-12 01:13:39 [INFO]  Backup completed: 2795MB written to /backups/snap_1776589659
2026-03-16 06:29:48 [WARN]  Disk usage at 63% on /var/log partition
2026-01-04 16:37:35 [INFO]  Backup completed: 950MB written to /backups/snap_1776761467
2026-02-12 12:39:44 [ERROR] Failed login attempt for user 'svc_backup' from 71.107.152.90
2026-06-19 06:30:46 [INFO]  Request from 92.2.138.76 - GET /api/v2/status - 200 OK
2026-06-13 07:14:56 [ERROR] Connection timeout to db-replica-21 after 6248ms
2026-01-02 06:46:40 [INFO]  Request from 29.58.95.156 - GET /api/v3/status - 200 OK
2026-11-25 05:49:18 [ERROR] Connection timeout to db-replica-14 after 4859ms
2026-04-07 14:21:39 [ERROR] Failed login attempt for user 'jdoe' from 125.238.187.131
2026-08-22 16:48:00 [ERROR] Connection timeout to db-replica-17 after 110ms
2026-10-19 15:42:22 [INFO]  Request from 105.216.28.118 - GET /api/v4/status - 200 OK
2026-06-11 10:20:58 [ERROR] Failed login attempt for user 'admin' from 173.242.111.51
2026-07-07 12:53:37 [INFO]  Backup completed: 1606MB written to /backups/snap_1777265255
[TOKEN] CodeandCapture{xsarueke-btmaspte-rkhnzfiv-whduenrq-ugedbpom-tfhrkpul}
[TOKEN] CodeandCapture{rlygunum-yjslqnws-zwvvixjj-uhhrfnqm-sygmwfiu-yfkksjrr}

Security training completion rate: 61% of Finance team. Outstanding: 24 employees.
Audit log retention policy updated. All logs older than 362 days will be purged automatically.
Security training completion rate: 89% of Engineering team. Outstanding: 14 employees.
[TOKEN] CodeandCapture{nfozmngw_a320ba}
[TOKEN] CodeandCapture{bfgwhyxj-pperyfpc-vmbozglc-oblzyrug-cldtrclf-xktgtwsr}
[TOKEN] CodeandCapture{kneenrignizbkxplukbl_XAIMBBAECV_0e6e4ae5}
