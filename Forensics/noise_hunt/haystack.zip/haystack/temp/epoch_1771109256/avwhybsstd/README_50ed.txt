2026-05-21 18:39:16 [INFO]  Request from 92.146.206.21 - GET /api/v2/status - 200 OK
The penetration test report (ref #PTR-9570) identified 2 medium-severity findings. Remediation deadline: January.
Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
2026-08-01 21:56:03 [ERROR] Failed login attempt for user 'svc_backup' from 27.89.133.168
[TOKEN] CodeandCapture{jycvzea plqvxyu rdcoqmu lxmuiaf rhuqckt sauxxdb extra}

Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam.
Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum.
Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
[TOKEN] CodeandCapture{vjorknlv-qottmswy-ywskvcio-xlwnpgjd-vpxjaqqi-amjsqrnw}

RSA_KEY_BITS = 4096
SESSION_EXPIRY = 86400
ALLOWED_ORIGINS = ["https://app.internal", "https://admin.corp"]

[TOKEN] CodeandCapture{invalid@symbol$in$here$plus$extra$length$fail}
[TOKEN] CodeandCapture{bfgwhyxj-pperyfpc-vmbozglc-oblzyrug-cldtrclf-xktgtwsr}

2026-01-12 00:26:03 [WARN]  High memory usage detected: 92% on node 11
2026-06-07 09:37:34 [ERROR] Failed login attempt for user 'msmith' from 46.99.100.46
2026-02-16 01:27:13 [WARN]  High memory usage detected: 74% on node 4
2026-05-23 06:38:20 [ERROR] Failed login attempt for user 'admin' from 180.19.98.5
2026-12-16 16:35:00 [WARN]  High memory usage detected: 79% on node 5
2026-04-17 05:03:07 [WARN]  High memory usage detected: 61% on node 8
2026-01-18 05:35:59 [WARN]  Disk usage at 99% on /var/log partition
2026-08-18 14:44:21 [INFO]  Backup completed: 3424MB written to /backups/snap_1777209707
2026-11-15 17:16:37 [DEBUG] Cache miss for key user_session_b5c606bec1aa
2026-05-19 09:59:29 [INFO]  Scheduled job 'cleanup_tmp' completed in 3191ms
2026-07-15 10:29:09 [INFO]  Scheduled job 'cleanup_tmp' completed in 1314ms
2026-01-19 21:02:11 [ERROR] Failed login attempt for user 'msmith' from 21.135.18.180
2026-09-06 08:24:29 [INFO]  Request from 106.62.70.10 - GET /api/v4/status - 200 OK
[TOKEN] CodeandCapture{b64:zxq3mSBH9o6RCaX4mEHRuqYkZZ+V}
[TOKEN] CodeandCapture{base64:aGVsbG8gd29ybGQgdGhpcyBpcyBub3QgaXQ=}
[TOKEN] flag{red_herring_6be376a4}

db_host = db-primary-4.internal
db_port = 5672
db_name = app_qa
max_connections = 200
[TOKEN] CodeandCapture{token_9412B403D206D16E_1757356047_EXP}
[TOKEN] CodeandCapture{fzynnvqbpaiqpao@rjzhpksifc#3fe0ecb8}

version: "3.9"
services:
  app:
    image: corp/backend:latest
    restart: unless-stopped
    ports:
      - "8080:8080"

[TOKEN] CodeandCapture{only_thirty_chars_here_nope}
[TOKEN] CodeandCapture{token_A2CF7B1D445FC20F_1774809139_EXP}
[TOKEN] CodeandCapture{ubaxtun uvlhmex eowhffl kdbqrga ognjsrd swssyyv extra}
