SELECT u.id, u.email, r.name FROM users u JOIN roles r ON u.role_id = r.id WHERE u.active = 1 LIMIT 100;

[TOKEN] CodeandCapture{b64:Ja2u+5sFDWrtpWlHgocmz4+KmtOJJg==}
[TOKEN] CodeandCapture{invalid@symbol$in$here$plus$extra$length$fail}
[TOKEN] CodeandCapture{b64:heDzsXp1FUqtY2om5g==}
[TOKEN] CodeandCapture{too_short}

Audit log retention policy updated. All logs older than 198 days will be purged automatically.
Security training completion rate: 83% of Marketing team. Outstanding: 2 employees.
The penetration test report (ref #PTR-9390) identified 14 medium-severity findings. Remediation deadline: October.
NOTICE: VPN certificates expire on 2026-05-28. Contact IT helpdesk (ext. 5227) to renew.
Audit log retention policy updated. All logs older than 340 days will be purged automatically.
Security training completion rate: 75% of DevOps team. Outstanding: 27 employees.
[TOKEN] C0deandCapture{l00ks_close_but_digit_in_prefix}
[TOKEN] CodeandCapture{ngpip_32f48e}
[TOKEN] CodeandCapture{token_2E4E097DFCA0B147_1751282067_EXP}

worker_count = 8
queue_size = 346
healthcheck_interval = 40s
graceful_shutdown = 30s
[TOKEN] CodeandCapture{cimlkgu xbtriuq ypwdrnz nywsohc nsifcvh mxhuasu extra}
[TOKEN] CodeandCapture{vetptim pypcxjo vtslujg apwqhfd cmcfxbz ymzcnzg extra}
[TOKEN] CodeandCapture{token_B70710EE225AA3C8_1777802393_EXP}
[TOKEN] CodeandCapture{jvvhbcbhurttrmjyzapt_XBFSDLJJXM_b7406a69}

2026-12-22 19:36:25 [ERROR] Failed login attempt for user 'jdoe' from 157.153.60.106
2026-02-12 03:35:27 [ERROR] Failed login attempt for user 'msmith' from 105.26.51.207
2026-09-23 12:05:42 [WARN]  Disk usage at 73% on /var/log partition
2026-04-26 06:38:50 [WARN]  High memory usage detected: 82% on node 3
2026-08-13 08:14:09 [INFO]  Scheduled job 'cleanup_tmp' completed in 5733ms
2026-07-18 23:03:22 [INFO]  Backup completed: 1129MB written to /backups/snap_1777246645
2026-10-23 10:21:21 [ERROR] Connection timeout to db-replica-30 after 5615ms
2026-02-22 20:49:39 [ERROR] Failed login attempt for user 'svc_backup' from 59.242.144.86
2026-03-25 16:17:10 [ERROR] Connection timeout to db-replica-15 after 7604ms
2026-11-07 06:10:51 [WARN]  High memory usage detected: 79% on node 12
2026-06-08 12:53:01 [ERROR] Failed login attempt for user 'root' from 76.244.45.24
2026-02-06 07:33:50 [ERROR] Connection timeout to db-replica-15 after 6463ms
2026-01-04 13:46:07 [INFO]  Backup completed: 1594MB written to /backups/snap_1776948396
2026-09-27 19:54:35 [DEBUG] Cache miss for key user_session_decb6f84385e
2026-10-17 23:23:11 [INFO]  Request from 80.196.109.91 - GET /api/v2/status - 200 OK
2026-05-14 16:39:38 [WARN]  Disk usage at 70% on /var/log partition
2026-12-04 00:21:26 [ERROR] Failed login attempt for user 'svc_backup' from 120.188.170.158
2026-08-21 21:18:30 [WARN]  Disk usage at 59% on /var/log partition
2026-01-20 02:50:53 [DEBUG] Cache miss for key user_session_9d47206682ea
[TOKEN] CodeandCapture{xsarueke-btmaspte-rkhnzfiv-whduenrq-ugedbpom-tfhrkpul}
[TOKEN] CodeandCapture{eyzljyjwenyborh@xvlduanzar#87cc3137}

{
  "bohoh": "cfcd61d9d6fe1276",
  "nreixb": 525,
  "jbjk": "ggqrcnmj",
  "ts": 1716777527
}
[TOKEN] CodeandCapture{zysydrahchnldlx@fdqksehxhj#384bb545}
[TOKEN] CodeandCapture{shcbfjithkhjafb@hpyeoqmomp#0957db0c}

cache_ttl = 85335
cache_backend = redis-5.internal:9200
cache_prefix = staging_
[TOKEN] CodeandCapture{ejaoadz khhxdlt uywdyqe jwoxbpa qvophkn rjxptlf extra}
[TOKEN] CodeandCapture{jkenvwwyamlzzbgtfger_KKLQPXKJGI_a616e071}

2026-04-02 05:18:31 [WARN]  Disk usage at 93% on /var/log partition
2026-12-27 03:31:27 [INFO]  Scheduled job 'cleanup_tmp' completed in 7615ms
2026-07-23 20:57:51 [WARN]  Disk usage at 82% on /var/log partition
2026-02-01 11:40:46 [WARN]  Disk usage at 78% on /var/log partition
2026-05-20 20:22:21 [DEBUG] Cache miss for key user_session_a250359caf9e
2026-06-08 16:07:33 [WARN]  Disk usage at 67% on /var/log partition
2026-08-13 07:05:17 [ERROR] Failed login attempt for user 'msmith' from 11.44.123.12
2026-11-14 10:00:39 [WARN]  High memory usage detected: 88% on node 5
2026-09-12 10:40:29 [WARN]  Disk usage at 63% on /var/log partition
2026-07-13 20:55:37 [WARN]  Disk usage at 98% on /var/log partition
2026-04-22 09:41:42 [WARN]  High memory usage detected: 69% on node 8
2026-03-16 10:17:00 [INFO]  Backup completed: 2473MB written to /backups/snap_1777544203
2026-12-05 19:18:10 [WARN]  High memory usage detected: 93% on node 5
2026-11-17 18:08:51 [ERROR] Connection timeout to db-replica-19 after 1879ms
2026-01-21 07:20:11 [DEBUG] Cache miss for key user_session_c813f1429e70
2026-02-22 18:04:57 [INFO]  Scheduled job 'cleanup_tmp' completed in 2121ms
2026-08-22 02:12:53 [WARN]  High memory usage detected: 54% on node 7
2026-07-23 02:22:27 [INFO]  Backup completed: 3403MB written to /backups/snap_1776881227
2026-03-25 08:02:30 [ERROR] Connection timeout to db-replica-24 after 1968ms
[TOKEN] CodeandCapture{mxbdtij clnchri tjgqfqn novspjn qhkplyt gqcfnmd extra}
[TOKEN] codeandcapture{all_lowercase_prefix_is_wrong_here}
