api_endpoint = https://internal-api-4.corp/v2
api_timeout = 44s
retry_limit = 2
[TOKEN] CodeAndCapture{wrong_case_in_the_middle_prefix}
[TOKEN] CodeandCapture{lxbinkooxhyp_9eb6cb}
[TOKEN] CodeandCapture{b64:NYycu35XvyxWRGrovGU5}
[TOKEN] CodeandCapture{token_B70710EE225AA3C8_1777802393_EXP}

cache_ttl = 72718
cache_backend = redis-11.internal:6379
cache_prefix = prod_
[TOKEN] CodeandCapture{unulzyjzmgldfxgnyhad_CZMRIJTTRP_5d81fe76}
[TOKEN] CodeandCapture{token_51DAE1C4BA27B95E_1771927283_EXP}

cache_ttl = 39111
cache_backend = redis-3.internal:9200
cache_prefix = qa_
[TOKEN] CodeandCapture{b64:hBLC0fjO9z4O1DA1I1sadPM+}
[TOKEN] CodeandCapture{aeijpmip-rinxhbwb-wqrzjoew-hxplpdqf-guqubahn-szvbxhhq}
[TOKEN] CodeandCapture{b64:GvCT5QdEN4ESf7xJN6A=}

2026-12-07 08:51:29 [ERROR] Failed login attempt for user 'devops' from 161.175.94.12
2026-07-18 00:45:51 [INFO]  Backup completed: 3040MB written to /backups/snap_1777425116
2026-07-23 07:31:38 [DEBUG] Cache miss for key user_session_07899981bbf9
2026-07-28 12:58:13 [INFO]  Request from 72.171.48.124 - GET /api/v4/status - 200 OK
2026-09-22 12:39:12 [WARN]  Disk usage at 69% on /var/log partition
2026-12-03 22:20:57 [INFO]  Scheduled job 'cleanup_tmp' completed in 7845ms
2026-11-04 02:16:12 [INFO]  Request from 169.48.251.82 - GET /api/v2/status - 200 OK
2026-07-17 20:48:02 [ERROR] Connection timeout to db-replica-7 after 8356ms
2026-09-01 21:26:05 [WARN]  High memory usage detected: 88% on node 9
2026-08-11 08:56:47 [ERROR] Connection timeout to db-replica-31 after 1475ms
2026-01-10 16:48:19 [ERROR] Failed login attempt for user 'root' from 138.191.165.46
2026-10-18 20:45:19 [WARN]  High memory usage detected: 77% on node 14
2026-12-10 10:25:06 [WARN]  Disk usage at 63% on /var/log partition
2026-02-13 23:31:53 [INFO]  Scheduled job 'cleanup_tmp' completed in 1366ms
2026-03-17 01:42:50 [ERROR] Connection timeout to db-replica-22 after 4827ms
2026-03-13 07:37:22 [WARN]  High memory usage detected: 68% on node 2
2026-09-24 16:04:50 [ERROR] Failed login attempt for user 'svc_backup' from 75.169.49.170
2026-11-16 12:34:48 [INFO]  Backup completed: 2498MB written to /backups/snap_1777214147
2026-07-03 10:36:23 [ERROR] Failed login attempt for user 'admin' from 34.150.168.193
2026-07-23 13:58:14 [INFO]  Scheduled job 'cleanup_tmp' completed in 1839ms
2026-09-14 05:19:31 [WARN]  Disk usage at 86% on /var/log partition
2026-02-02 11:06:04 [INFO]  Scheduled job 'cleanup_tmp' completed in 1794ms
2026-06-11 10:35:32 [ERROR] Failed login attempt for user 'admin' from 59.165.97.33
2026-08-10 08:43:53 [INFO]  Request from 125.57.126.91 - GET /api/v1/status - 200 OK
2026-12-08 03:20:00 [ERROR] Connection timeout to db-replica-6 after 2774ms
2026-01-14 14:53:16 [DEBUG] Cache miss for key user_session_af3816eb33d7
2026-09-03 19:24:00 [INFO]  Scheduled job 'cleanup_tmp' completed in 4883ms
[TOKEN] CodeandCapture{b64:NYycu35XvyxWRGrovGU5}
[TOKEN] CodeandCapture{tzcmtau_344fab}
[TOKEN] flag{invalid@symbol}
[TOKEN] CodeandCapture{b64:VpzRK9/w331jLpC3ZTMbHw==}

Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.
In dui magna, posuere eget, vestibulum et, tempor auctor, justo. In ac felis quis tortor malesuada pretium.
Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam.
Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam.
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
[TOKEN] flag{almost_there_84c5ed1f}

2026-01-18 08:46:13 [ERROR] Failed login attempt for user 'jdoe' from 136.1.3.241
2026-10-25 00:05:49 [ERROR] Connection timeout to db-replica-22 after 5325ms
2026-08-05 09:49:16 [ERROR] Connection timeout to db-replica-12 after 1527ms
2026-03-08 15:47:26 [INFO]  Request from 109.209.135.129 - GET /api/v1/status - 200 OK
2026-02-21 19:33:19 [INFO]  Request from 108.38.87.31 - GET /api/v4/status - 200 OK
2026-01-15 06:38:24 [DEBUG] Cache miss for key user_session_d8a21e536990
2026-08-17 15:36:01 [INFO]  Scheduled job 'cleanup_tmp' completed in 3949ms
2026-08-03 08:58:53 [INFO]  Scheduled job 'cleanup_tmp' completed in 2079ms
2026-10-02 02:45:43 [INFO]  Request from 29.190.71.122 - GET /api/v3/status - 200 OK
2026-03-08 10:00:50 [WARN]  High memory usage detected: 78% on node 9
2026-01-20 09:15:43 [INFO]  Scheduled job 'cleanup_tmp' completed in 1039ms
2026-09-21 16:04:25 [INFO]  Backup completed: 1264MB written to /backups/snap_1777383707
2026-10-10 15:47:00 [DEBUG] Cache miss for key user_session_2250ede4b057
2026-07-01 20:23:00 [WARN]  High memory usage detected: 51% on node 1
2026-04-22 19:40:23 [INFO]  Request from 72.223.114.152 - GET /api/v1/status - 200 OK
2026-06-20 14:16:52 [WARN]  Disk usage at 75% on /var/log partition
2026-09-28 17:20:13 [WARN]  Disk usage at 80% on /var/log partition
2026-09-20 04:44:50 [ERROR] Connection timeout to db-replica-30 after 7342ms
2026-08-27 02:50:16 [INFO]  Request from 94.108.168.235 - GET /api/v3/status - 200 OK
2026-12-20 06:11:24 [INFO]  Scheduled job 'cleanup_tmp' completed in 5705ms
2026-12-15 19:39:56 [INFO]  Scheduled job 'cleanup_tmp' completed in 1749ms
2026-03-24 04:57:39 [INFO]  Backup completed: 2581MB written to /backups/snap_1776804005
2026-10-03 03:09:50 [WARN]  High memory usage detected: 88% on node 14
2026-12-23 02:37:34 [DEBUG] Cache miss for key user_session_9d5b53af99dd
2026-02-04 18:58:58 [ERROR] Connection timeout to db-replica-15 after 2180ms
2026-12-17 08:36:02 [WARN]  High memory usage detected: 76% on node 14
2026-08-11 18:53:13 [DEBUG] Cache miss for key user_session_1c83f26de16d
[TOKEN] CodeCapture{auth_secret_5d0a160b}
[TOKEN] CodeandCapture{ridmyprbmrazhsnlumqd_QUHHVZBYMI_5766d6f8}

ac 09 fc ec 45 6b 6a 3b 76 9d 39 b8 60 1f 6c a3 2c 38 09 95 28 6b 55 46 f4 e4 35 d5 84 c1 44 56 a9 ee 87 07 31 dc 92 e1 38 cc 69 a2 8b 1f d0 de 42 56 bb c8 7d 38 8f 4f e6 eb 64 82 13 c9 9d b5 51 1f d1 f6 42 f0 87 46 b7 7f 7e 66 e5 9e 0e cc fc da a3
[TOKEN] CandCapture{system_token_e40bc45f}
[TOKEN] CodeandCapture{wvjghbu bttnlwy objjwof lacuwhd wufhdas sbvwmrt extra}
[TOKEN] CodeandCapture{b64:yGme8ytZbemO+haOhuf9}

api_endpoint = https://internal-api-7.corp/v2
api_timeout = 6s
retry_limit = 5
[TOKEN] CodeandCapture{niphiuat-fzupgtlq-nzyulhyt-clppwcag-gmtjvuif-jpzjzfqg}
[TOKEN] CodeandCapture{iyjgesh_8a27d6}
[TOKEN] Codeandcapture{not_real_73094fc5}

2026-07-23 17:39:02 [WARN]  High memory usage detected: 95% on node 7
2026-02-24 17:34:52 [INFO]  Scheduled job 'cleanup_tmp' completed in 2381ms
2026-11-08 07:01:11 [INFO]  Scheduled job 'cleanup_tmp' completed in 4878ms
2026-09-24 23:09:50 [WARN]  Disk usage at 94% on /var/log partition
2026-10-02 11:28:17 [INFO]  Backup completed: 596MB written to /backups/snap_1777276574
2026-02-04 14:19:49 [WARN]  High memory usage detected: 83% on node 13
2026-05-13 19:04:46 [ERROR] Connection timeout to db-replica-16 after 5775ms
2026-12-24 20:15:19 [INFO]  Scheduled job 'cleanup_tmp' completed in 6740ms
2026-11-06 16:48:01 [ERROR] Failed login attempt for user 'root' from 167.32.137.125
2026-09-26 03:49:18 [WARN]  High memory usage detected: 79% on node 3
2026-04-02 05:19:39 [WARN]  High memory usage detected: 88% on node 4
2026-07-02 23:10:31 [WARN]  Disk usage at 68% on /var/log partition
2026-04-17 11:50:11 [ERROR] Connection timeout to db-replica-24 after 1327ms
2026-03-17 00:47:46 [WARN]  High memory usage detected: 60% on node 8
2026-09-23 11:34:55 [WARN]  Disk usage at 78% on /var/log partition
2026-10-14 03:29:54 [WARN]  High memory usage detected: 95% on node 6
2026-11-08 22:26:20 [INFO]  Backup completed: 223MB written to /backups/snap_1777193187
2026-10-27 02:19:34 [ERROR] Connection timeout to db-replica-8 after 7599ms
2026-10-04 02:37:58 [INFO]  Backup completed: 2058MB written to /backups/snap_1777302840
2026-03-28 17:18:26 [ERROR] Connection timeout to db-replica-29 after 3525ms
2026-09-24 23:38:48 [DEBUG] Cache miss for key user_session_002607e5fb7f
2026-07-19 20:47:10 [ERROR] Connection timeout to db-replica-31 after 5437ms
2026-09-17 05:44:22 [INFO]  Backup completed: 1603MB written to /backups/snap_1777501788
2026-11-14 06:46:32 [WARN]  High memory usage detected: 69% on node 2
2026-09-14 00:30:36 [INFO]  Request from 18.187.181.60 - GET /api/v3/status - 200 OK
2026-12-20 05:46:54 [ERROR] Connection timeout to db-replica-13 after 6395ms
2026-10-17 22:10:08 [INFO]  Backup completed: 2108MB written to /backups/snap_1777201694
2026-01-19 17:54:57 [WARN]  Disk usage at 98% on /var/log partition
[TOKEN] CodeandCapture{hgrgnvmhzayjnwkhbhpm_XFBBOBCDXK_9f3e5259}
[TOKEN] CodeandCapture{crgnlpodxdmqlpk@sesptmnhoh#502d6d1e}
[TOKEN] CodeCapture{auth_secret_5d0a160b}
[TOKEN] codeandcapture{all_lowercase_prefix_is_wrong_here}
