curl -X POST https://api.internal/auth -H "Content-Type: application/json" -d '{"user":"admin","pass":"****"}'

[TOKEN] CodeandCapture{uispushnufeuqjjgjkxt_CVQONGKUAW_1a538d00}
[TOKEN] CodeandCapture{sflzswswhjbkuiv@opqbtsvtqp#e3e71996}
[TOKEN] CodeandCapture{b64:xOOCZiWepbGXA2g6c3K6}

2026-04-08 22:31:50 [DEBUG] Cache miss for key user_session_227b47c6d33a
2026-05-01 10:32:10 [INFO]  Scheduled job 'cleanup_tmp' completed in 8083ms
2026-01-10 11:42:41 [WARN]  Disk usage at 53% on /var/log partition
2026-01-26 13:47:53 [INFO]  Scheduled job 'cleanup_tmp' completed in 2472ms
2026-05-16 02:05:07 [ERROR] Connection timeout to db-replica-10 after 4362ms
2026-09-10 16:00:45 [INFO]  Backup completed: 608MB written to /backups/snap_1777122304
2026-09-18 17:16:44 [WARN]  High memory usage detected: 85% on node 3
2026-05-16 05:36:00 [WARN]  Disk usage at 80% on /var/log partition
2026-12-09 14:14:04 [ERROR] Failed login attempt for user 'devops' from 18.67.78.30
2026-12-13 07:18:47 [DEBUG] Cache miss for key user_session_d742abc26fc7
2026-01-11 13:48:20 [INFO]  Request from 155.109.140.120 - GET /api/v1/status - 200 OK
2026-06-27 02:01:58 [WARN]  Disk usage at 79% on /var/log partition
2026-07-16 21:58:39 [ERROR] Connection timeout to db-replica-13 after 8251ms
2026-09-17 23:16:52 [DEBUG] Cache miss for key user_session_65abccd49826
2026-11-11 05:59:21 [DEBUG] Cache miss for key user_session_2276a4baffa8
2026-02-26 05:01:12 [INFO]  Request from 105.44.5.188 - GET /api/v3/status - 200 OK
2026-08-15 19:14:08 [WARN]  High memory usage detected: 97% on node 7
2026-07-01 04:15:33 [DEBUG] Cache miss for key user_session_55b72424d599
2026-04-28 18:49:44 [INFO]  Backup completed: 2277MB written to /backups/snap_1777225713
[TOKEN] CodeandCapture{zjlaiim ooqwoxa riqixme tbudrrv xxnswkg jqhyawo extra}

2026-05-26 15:02:03 [INFO]  Request from 174.139.204.188 - GET /api/v2/status - 200 OK
Reminder: rotate credentials on db-17 before the 11th. Ticket #62326 is still open.
Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.
2026-08-28 17:47:50 [ERROR] Connection timeout to db-replica-2 after 5125ms
[TOKEN] CodeandCapture{token_12D07451AFA7C493_1746473829_EXP}

2026-11-24 09:57:43 [DEBUG] Cache miss for key user_session_ccb95651057f
2026-01-28 02:41:13 [DEBUG] Cache miss for key user_session_06a4da135a81
2026-10-26 14:11:15 [DEBUG] Cache miss for key user_session_ee381b9965bf
2026-04-12 23:37:36 [INFO]  Backup completed: 1869MB written to /backups/snap_1776895518
2026-01-27 05:43:42 [INFO]  Scheduled job 'cleanup_tmp' completed in 3682ms
2026-09-13 20:31:56 [INFO]  Backup completed: 3698MB written to /backups/snap_1776931139
2026-04-18 08:58:34 [INFO]  Backup completed: 3425MB written to /backups/snap_1776663967
2026-02-02 22:56:45 [WARN]  High memory usage detected: 94% on node 1
2026-01-03 08:26:02 [WARN]  High memory usage detected: 56% on node 14
2026-04-10 12:05:56 [INFO]  Request from 169.179.86.245 - GET /api/v4/status - 200 OK
2026-12-09 19:53:17 [INFO]  Scheduled job 'cleanup_tmp' completed in 2748ms
2026-12-13 22:42:31 [INFO]  Backup completed: 2678MB written to /backups/snap_1776623925
2026-12-13 14:23:55 [INFO]  Backup completed: 2509MB written to /backups/snap_1776784284
2026-10-24 04:05:59 [WARN]  High memory usage detected: 75% on node 12
2026-02-05 03:07:59 [INFO]  Scheduled job 'cleanup_tmp' completed in 410ms
2026-11-01 16:19:06 [INFO]  Request from 173.220.33.204 - GET /api/v4/status - 200 OK
2026-05-03 05:36:02 [ERROR] Connection timeout to db-replica-17 after 6636ms
2026-10-27 21:28:25 [INFO]  Scheduled job 'cleanup_tmp' completed in 6323ms
2026-06-03 03:53:48 [INFO]  Backup completed: 412MB written to /backups/snap_1777458996
2026-03-01 19:32:01 [ERROR] Connection timeout to db-replica-21 after 4922ms
2026-02-02 00:18:25 [WARN]  High memory usage detected: 60% on node 14
2026-06-02 15:32:33 [WARN]  High memory usage detected: 97% on node 7
2026-07-20 04:51:32 [ERROR] Failed login attempt for user 'svc_backup' from 19.92.26.89
[TOKEN] CodeandCapture{lxbinkooxhyp_9eb6cb}
[TOKEN] CodeandCapture{vetptim pypcxjo vtslujg apwqhfd cmcfxbz ymzcnzg extra}
