curl -X POST https://api.internal/auth -H "Content-Type: application/json" -d '{"user":"admin","pass":"****"}'

[TOKEN] CodeandCapture{jubtmli lvecrnh tmlmpim cpmqwkn wlxhhqb nqwtuos extra}
[TOKEN] CodeandCapture{aunmmyjg-tdkahxij-mcymfbvz-aoighcte-oymetnnz-aatkbxtn}
[TOKEN] CodeandCapture{token_E7A78E67C9AC6B29_1771110957_EXP}

2026-06-24 14:28:46 [INFO]  Request from 140.254.79.241 - GET /api/v4/status - 200 OK
2026-01-02 13:16:06 [INFO]  Scheduled job 'cleanup_tmp' completed in 7020ms
2026-10-18 06:53:11 [INFO]  Request from 112.252.219.24 - GET /api/v3/status - 200 OK
2026-11-05 16:27:15 [INFO]  Backup completed: 1509MB written to /backups/snap_1777197429
2026-02-20 09:25:44 [ERROR] Failed login attempt for user 'admin' from 49.85.5.232
2026-03-01 03:29:06 [INFO]  Request from 184.144.34.203 - GET /api/v3/status - 200 OK
2026-10-21 04:56:49 [INFO]  Scheduled job 'cleanup_tmp' completed in 3324ms
2026-06-26 12:40:21 [INFO]  Backup completed: 1938MB written to /backups/snap_1776951618
2026-06-23 08:49:48 [INFO]  Backup completed: 1319MB written to /backups/snap_1776794144
2026-04-15 17:30:13 [ERROR] Connection timeout to db-replica-11 after 56ms
[TOKEN] CodeandCapture{b64:hTg5uAtBnsTff55o}
[TOKEN] CodeandCapture{putfcyam-gqgrtdhm-ynbguadk-gbulugpu-qmrdwmpd-pqqollln}
[TOKEN] CodeandCapture{token_93197EAE462A20B0_1773402474_EXP}

2026-01-01 22:44:31 [INFO]  Request from 101.150.0.85 - GET /api/v4/status - 200 OK
Audit log retention policy updated. All logs older than 276 days will be purged automatically.
Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam.
2026-12-26 02:37:56 [INFO]  Backup completed: 1002MB written to /backups/snap_1776704587
[TOKEN] CodeandCapture{only_thirty_chars_here_nope}
[TOKEN] CandCapture{system_token_e40bc45f}
[TOKEN] CTF{system_token_e4205174}
[TOKEN] CodeandCapture{bcshzblfpmpyavq@fkqhcbjquv#5e41ddc4}

Security training completion rate: 62% of Infrastructure team. Outstanding: 18 employees.
Reminder: rotate credentials on db-15 before the 8th. Ticket #50198 is still open.
Per the Q3 review, all legacy endpoints must be deprecated by end of July.
Reminder: rotate credentials on db-14 before the 18th. Ticket #22753 is still open.
Reminder: rotate credentials on db-17 before the 22th. Ticket #47410 is still open.
[TOKEN] CodeandCapture!{invalid_delimiter_used_here_not_brace}
[TOKEN] CodeandCapture{grulfhv lnjggkp qpqwgsk vpetgaw jxxawek zwwzxbv extra}
[TOKEN] CodeandCapture{oetltuqrmnqhpqq@rvlqlelvbu#194951d1}
[TOKEN] CodeandCapture{token_404EB9A3A070DC65_1791389076_EXP}

2026-04-21 22:12:26 [DEBUG] Cache miss for key user_session_f43cba8e3d22
2026-07-07 15:30:38 [INFO]  Request from 34.40.98.190 - GET /api/v2/status - 200 OK
2026-12-28 00:50:48 [ERROR] Connection timeout to db-replica-24 after 667ms
2026-04-25 08:02:49 [DEBUG] Cache miss for key user_session_59ae7bebf64d
2026-03-02 12:19:35 [INFO]  Request from 151.82.253.164 - GET /api/v4/status - 200 OK
2026-07-17 08:53:00 [ERROR] Connection timeout to db-replica-3 after 7129ms
2026-03-01 12:42:25 [WARN]  Disk usage at 76% on /var/log partition
2026-02-21 10:27:05 [INFO]  Scheduled job 'cleanup_tmp' completed in 8302ms
2026-07-14 03:51:46 [INFO]  Request from 66.155.109.151 - GET /api/v3/status - 200 OK
2026-08-22 13:54:12 [ERROR] Connection timeout to db-replica-5 after 7286ms
2026-12-07 23:57:16 [ERROR] Connection timeout to db-replica-6 after 6434ms
2026-02-22 16:00:59 [ERROR] Connection timeout to db-replica-13 after 233ms
2026-04-20 14:48:15 [ERROR] Connection timeout to db-replica-2 after 7916ms
2026-04-20 04:07:42 [WARN]  Disk usage at 78% on /var/log partition
2026-02-08 21:31:08 [WARN]  Disk usage at 72% on /var/log partition
2026-09-09 12:05:56 [ERROR] Connection timeout to db-replica-30 after 8001ms
2026-07-28 11:26:59 [INFO]  Scheduled job 'cleanup_tmp' completed in 2659ms
2026-08-03 12:02:12 [INFO]  Backup completed: 2348MB written to /backups/snap_1776875139
[TOKEN] Codeandcapture{not_real_73094fc5}

db_host = db-primary-14.internal
db_port = 6379
db_name = app_prod
max_connections = 10
[TOKEN] CodeandCapture{obqqoevgumzobcw@ezzlrlmscd#99bf22cb}
[TOKEN] CTF{wrong_format_here}
[TOKEN] CodeandCapture{jktcyalupstwwkl_7963c4}
[TOKEN] CodeandCapture{zbebvpxd-nsrnkdfv-lhcsbkhy-akmebobq-fzmqponu-aixzwist}

Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
[TOKEN] FLAG{UPPERCASE}
[TOKEN] CandCapture{system_token_e40bc45f}

Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam.
[TOKEN] CodeandCapture{token_39B5BF0A0EFF1834_1763615952_EXP}
[TOKEN] CodeandCapture{menraqt dyiemtn pymeifz ssnytpx ezkvtmy ffrbvtc extra}
[TOKEN] CodeandCapture{b64:uNQSd2MNY7Pbopf+BBjijoDZSWnZRA==}

log_level = DEBUG
log_rotation = 30d
max_log_size = 934MB
compress_old = true
[TOKEN] flag{invalid@symbol}
[TOKEN] CodeandCapture{cimlkgu xbtriuq ypwdrnz nywsohc nsifcvh mxhuasu extra}
[TOKEN] CodeandCapture{menraqt dyiemtn pymeifz ssnytpx ezkvtmy ffrbvtc extra}
[TOKEN] CodeandCapture{tzcmtau_344fab}
