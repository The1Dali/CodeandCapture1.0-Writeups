def authenticate(user, token):
    h = hashlib.sha256(token.encode()).hexdigest()
    return h == DB.get_token_hash(user)

[TOKEN] CodeandCapture{adcpypvvrwzhwxr@lcyphplvkh#352e0011}
[TOKEN] CodeandCapture{jjktqnkbcctavnf@vshnhgafnl#fc230dc8}
[TOKEN] CodeandCapture{bfgwhyxj-pperyfpc-vmbozglc-oblzyrug-cldtrclf-xktgtwsr}
[TOKEN] CodeandCapture{sznwkg_65483a}

Reminder: rotate credentials on db-20 before the 13th. Ticket #92622 is still open.
The penetration test report (ref #PTR-1151) identified 24 medium-severity findings. Remediation deadline: October.
Reminder: rotate credentials on db-8 before the 21th. Ticket #83559 is still open.
[TOKEN] codeandcapture{try_harder_f75b8a07}
[TOKEN] CodeandCapture{lvnynwhzvfahqme@bmhgdtgaay#1bb1d91a}
[TOKEN] Flag{wrongcase}
[TOKEN] CodeandCapture{only_thirty_chars_here_nope}

Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.
Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
[TOKEN] flag{123too_short}
[TOKEN] CodeandCapture{b64:hBLC0fjO9z4O1DA1I1sadPM+}
[TOKEN] Codeandcapture{not_real_73094fc5}

Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
[TOKEN] CodeandCapture{b64:lZhZ0DNTrD7zT46PP4abBt90tw==}
[TOKEN] CodeandCapture{cbgqhxb_0316a6}
