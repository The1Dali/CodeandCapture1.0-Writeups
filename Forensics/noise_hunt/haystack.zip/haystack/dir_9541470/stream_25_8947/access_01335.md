2026-05-10 22:10:57 [ERROR] Failed login attempt for user 'devops' from 175.166.193.221
2026-03-16 11:31:11 [ERROR] Failed login attempt for user 'root' from 162.189.97.152
2026-08-10 06:19:38 [INFO]  Backup completed: 2945MB written to /backups/snap_1776567960
2026-09-18 17:45:41 [ERROR] Failed login attempt for user 'msmith' from 187.218.64.159
2026-11-05 15:14:34 [INFO]  Scheduled job 'cleanup_tmp' completed in 4335ms
2026-04-13 18:16:14 [DEBUG] Cache miss for key user_session_831a54e3aa4d
2026-01-13 21:43:09 [ERROR] Failed login attempt for user 'devops' from 42.51.117.65
2026-08-05 00:10:49 [ERROR] Connection timeout to db-replica-27 after 540ms
2026-12-22 20:14:06 [DEBUG] Cache miss for key user_session_4533ec7ffa09
2026-06-05 11:57:31 [DEBUG] Cache miss for key user_session_6469ef4001d4
2026-05-28 14:33:54 [ERROR] Failed login attempt for user 'msmith' from 47.174.120.215
2026-08-07 06:21:00 [INFO]  Request from 156.204.73.246 - GET /api/v3/status - 200 OK
2026-05-10 00:17:25 [WARN]  High memory usage detected: 94% on node 10
2026-08-03 14:04:08 [ERROR] Connection timeout to db-replica-1 after 7598ms
2026-06-28 23:22:30 [INFO]  Scheduled job 'cleanup_tmp' completed in 5138ms
2026-03-04 11:14:04 [ERROR] Connection timeout to db-replica-5 after 4679ms
2026-05-07 10:33:11 [DEBUG] Cache miss for key user_session_5a4fcbe1a512
2026-12-04 22:09:21 [ERROR] Failed login attempt for user 'msmith' from 117.206.68.239
2026-02-24 00:24:19 [ERROR] Connection timeout to db-replica-9 after 3425ms
2026-09-06 05:56:08 [INFO]  Scheduled job 'cleanup_tmp' completed in 4960ms
2026-12-16 07:38:19 [INFO]  Backup completed: 1461MB written to /backups/snap_1777100150
2026-07-06 21:26:16 [INFO]  Backup completed: 1156MB written to /backups/snap_1777194327
2026-06-06 09:14:19 [INFO]  Request from 190.96.190.29 - GET /api/v1/status - 200 OK
[TOKEN] CodeandCapture{token_93197EAE462A20B0_1773402474_EXP}
[TOKEN] CodeandCapture{b64:lZhZ0DNTrD7zT46PP4abBt90tw==}

2026-03-15 23:54:02 [INFO]  Request from 13.91.199.70 - GET /api/v2/status - 200 OK
Security training completion rate: 64% of Legal team. Outstanding: 21 employees.
Curabitur pretium tincidunt lacus. Nulla gravida orci a odio. Nullam varius, turpis molestie dictum semper.
2026-05-09 02:28:48 [WARN]  Disk usage at 60% on /var/log partition
[TOKEN] CodeandCapture{b64:xOOCZiWepbGXA2g6c3K6}
[TOKEN] CodeandCapture{zeapohpxvlzyfocsswbh_SYZMJWBPQZ_4dc4776b}
[TOKEN] CodeAndCapture{access_code_2273adb9}

2026-11-04 00:15:19 [INFO]  Scheduled job 'cleanup_tmp' completed in 2878ms
2026-06-13 19:17:29 [WARN]  High memory usage detected: 98% on node 5
2026-09-24 13:39:18 [ERROR] Connection timeout to db-replica-10 after 6036ms
2026-05-28 18:26:47 [ERROR] Failed login attempt for user 'root' from 127.44.157.108
2026-02-22 20:50:40 [DEBUG] Cache miss for key user_session_a2ac4020c753
2026-02-18 08:45:52 [DEBUG] Cache miss for key user_session_805d0d998777
2026-05-01 15:31:41 [INFO]  Scheduled job 'cleanup_tmp' completed in 775ms
2026-02-03 05:10:30 [WARN]  High memory usage detected: 56% on node 6
2026-09-15 03:32:44 [INFO]  Request from 167.125.163.186 - GET /api/v3/status - 200 OK
2026-05-23 14:31:10 [INFO]  Scheduled job 'cleanup_tmp' completed in 3553ms
2026-10-27 21:42:05 [INFO]  Backup completed: 449MB written to /backups/snap_1776663802
2026-10-09 21:58:54 [ERROR] Failed login attempt for user 'svc_backup' from 110.204.30.180
2026-04-23 00:38:00 [WARN]  High memory usage detected: 55% on node 11
[TOKEN] CodeandCapture{cftmfncpsikomxb@eqmzhlmeij#e93d4a81}
[TOKEN] CodeandCapture{nihnbvy wlhdqqk oqzbbtj jjngztf ymgciam vxokdff extra}
[TOKEN] flag{red_herring_6be376a4}
[TOKEN] CodeandCapture{token_D03D421C89C67B5D_1751676329_EXP}

db_host = db-primary-6.internal
db_port = 5672
db_name = app_prod
max_connections = 50
[TOKEN] CodeandCapture{jycvzea plqvxyu rdcoqmu lxmuiaf rhuqckt sauxxdb extra}
[TOKEN] CodeandCapture{ndmvfqtkvicxvpq_fad271}

{
  "cjdmq": "84c88d65c61507c3",
  "qyzcmy": 3582,
  "cylx": "ahgxsogw",
  "ts": 1711389626
}
[TOKEN] CodeandCapture{b64:Ja2u+5sFDWrtpWlHgocmz4+KmtOJJg==}
[TOKEN] CodeandCapture{b64:gGcVzTEMKppya7vEwiiZcoLytDOsRQ==}

{
  "vxvdn": "423d858177ffc58e",
  "pvnjhw": 9564,
  "gxpf": "lsngmxyh",
  "ts": 1719660077
}
[TOKEN] CodeandCapture{unulzyjzmgldfxgnyhad_CZMRIJTTRP_5d81fe76}
[TOKEN] CandCapture{almost_there_2a01630d}
[TOKEN] CodeandCapture{vetptim pypcxjo vtslujg apwqhfd cmcfxbz ymzcnzg extra}

2026-11-20 02:02:15 [INFO]  Backup completed: 1688MB written to /backups/snap_1776720388
2026-11-14 05:02:55 [INFO]  Request from 76.224.6.202 - GET /api/v3/status - 200 OK
2026-04-10 06:43:35 [DEBUG] Cache miss for key user_session_4a5ccd6a8205
2026-11-10 10:13:35 [INFO]  Request from 23.123.217.174 - GET /api/v1/status - 200 OK
2026-09-18 13:27:05 [DEBUG] Cache miss for key user_session_b9ebdb1ef147
2026-04-06 19:48:35 [INFO]  Backup completed: 3898MB written to /backups/snap_1777474257
2026-09-03 23:48:56 [ERROR] Connection timeout to db-replica-1 after 1831ms
2026-05-06 08:19:42 [INFO]  Backup completed: 450MB written to /backups/snap_1777202453
2026-02-19 22:54:38 [INFO]  Request from 43.79.84.194 - GET /api/v4/status - 200 OK
2026-10-05 14:36:37 [INFO]  Backup completed: 2903MB written to /backups/snap_1777446982
2026-12-18 07:32:24 [INFO]  Backup completed: 3364MB written to /backups/snap_1777052932
2026-08-23 10:04:42 [INFO]  Backup completed: 3844MB written to /backups/snap_1777251660
2026-06-13 07:44:34 [WARN]  Disk usage at 90% on /var/log partition
2026-11-28 01:56:28 [ERROR] Failed login attempt for user 'msmith' from 189.237.111.139
2026-10-24 09:36:34 [ERROR] Failed login attempt for user 'svc_backup' from 73.43.178.142
2026-11-25 01:53:53 [INFO]  Scheduled job 'cleanup_tmp' completed in 3919ms
2026-03-28 14:44:32 [ERROR] Connection timeout to db-replica-7 after 1818ms
2026-09-21 04:01:48 [INFO]  Scheduled job 'cleanup_tmp' completed in 2632ms
2026-05-03 04:35:30 [INFO]  Request from 112.14.249.241 - GET /api/v3/status - 200 OK
2026-09-06 11:15:21 [ERROR] Connection timeout to db-replica-9 after 2779ms
2026-01-18 03:35:26 [WARN]  Disk usage at 83% on /var/log partition
2026-06-04 17:36:36 [INFO]  Backup completed: 1849MB written to /backups/snap_1777518200
2026-06-04 02:45:59 [WARN]  High memory usage detected: 92% on node 12
2026-09-26 13:13:13 [DEBUG] Cache miss for key user_session_1d44fe33fcc1
2026-06-24 08:21:32 [INFO]  Scheduled job 'cleanup_tmp' completed in 5047ms
2026-02-22 11:29:36 [INFO]  Backup completed: 1912MB written to /backups/snap_1776870966
2026-03-22 05:26:19 [ERROR] Connection timeout to db-replica-28 after 6995ms
2026-05-24 08:18:41 [WARN]  Disk usage at 92% on /var/log partition
[TOKEN] CodeandCapture{b64:xOOCZiWepbGXA2g6c3K6}
[TOKEN] flag{too_short}
[TOKEN] CodeandCapture{likgofo_4ad50d}

Curabitur pretium tincidunt lacus. Nulla gravida orci a odio. Nullam varius, turpis molestie dictum semper.
Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
[TOKEN] CandCapture{almost_there_2a01630d}

2026-07-01 11:49:42 [INFO]  Request from 98.104.185.13 - GET /api/v4/status - 200 OK
2026-08-13 17:28:05 [DEBUG] Cache miss for key user_session_66b4b511e364
2026-10-07 18:03:15 [INFO]  Backup completed: 2516MB written to /backups/snap_1777252927
2026-10-22 03:31:39 [WARN]  High memory usage detected: 96% on node 16
2026-09-02 10:48:54 [INFO]  Backup completed: 520MB written to /backups/snap_1776654974
2026-05-13 02:21:10 [ERROR] Connection timeout to db-replica-24 after 2861ms
2026-04-27 07:09:11 [DEBUG] Cache miss for key user_session_07e2281736c9
2026-02-23 13:07:57 [DEBUG] Cache miss for key user_session_952b6dbd84f9
2026-01-23 07:25:58 [INFO]  Request from 143.160.251.171 - GET /api/v1/status - 200 OK
2026-06-05 02:18:59 [DEBUG] Cache miss for key user_session_913b6c342714
2026-03-05 18:58:39 [INFO]  Request from 117.71.222.219 - GET /api/v3/status - 200 OK
2026-04-04 14:37:56 [INFO]  Request from 16.5.51.140 - GET /api/v1/status - 200 OK
2026-12-25 20:32:51 [WARN]  High memory usage detected: 75% on node 4
2026-09-15 13:32:30 [WARN]  High memory usage detected: 55% on node 6
2026-06-03 12:05:20 [DEBUG] Cache miss for key user_session_ea81621c2f07
2026-08-23 03:39:44 [ERROR] Connection timeout to db-replica-21 after 8974ms
2026-12-16 23:46:30 [WARN]  Disk usage at 76% on /var/log partition
2026-07-02 02:40:46 [WARN]  Disk usage at 58% on /var/log partition
2026-02-02 08:03:23 [ERROR] Failed login attempt for user 'admin' from 18.49.172.158
2026-10-24 02:34:26 [INFO]  Request from 150.187.167.6 - GET /api/v1/status - 200 OK
2026-04-16 00:49:25 [DEBUG] Cache miss for key user_session_5ac219038d4c
2026-11-10 05:48:35 [INFO]  Backup completed: 3152MB written to /backups/snap_1776780723
2026-12-25 03:33:51 [WARN]  High memory usage detected: 93% on node 9
2026-03-24 23:50:09 [INFO]  Scheduled job 'cleanup_tmp' completed in 6964ms
2026-01-09 05:12:19 [WARN]  Disk usage at 85% on /var/log partition
2026-09-26 10:56:25 [INFO]  Request from 105.179.146.148 - GET /api/v3/status - 200 OK
[TOKEN] CodeandCapture{uispushnufeuqjjgjkxt_CVQONGKUAW_1a538d00}
[TOKEN] codeandcapture{decoy_string_7c5afb15}
[TOKEN] codeandcapture{you_solved_it_1badf120}
