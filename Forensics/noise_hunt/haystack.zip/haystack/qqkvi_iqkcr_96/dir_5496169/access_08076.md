version: "3.9"
services:
  app:
    image: corp/backend:latest
    restart: unless-stopped
    ports:
      - "8080:8080"

[TOKEN] CodeandCapture{yaamnnqowztdiyn@ijgwahcipi#83fb4fe5}
[TOKEN] CodeandCapture{hzshmanj-fekzdpxt-lvauwxxc-fwtihzgu-csbmoqkz-gfojklkm}
[TOKEN] codeandcapture{session_key_3a95b075}
[TOKEN] CodeandCapture{wjvjmvglcalxgsdkqlen_GGUBGQBSHP_db42b215}

2026-10-01 11:39:27 [DEBUG] Cache miss for key user_session_c234c3d679bc
2026-11-19 15:30:14 [ERROR] Failed login attempt for user 'jdoe' from 39.253.206.183
2026-02-14 01:06:37 [ERROR] Failed login attempt for user 'jdoe' from 27.12.162.48
2026-11-20 13:45:08 [ERROR] Failed login attempt for user 'devops' from 172.24.140.139
2026-06-11 21:15:40 [WARN]  High memory usage detected: 59% on node 8
2026-12-08 12:58:34 [ERROR] Connection timeout to db-replica-12 after 63ms
2026-04-09 09:12:30 [WARN]  High memory usage detected: 73% on node 16
2026-09-25 13:14:34 [WARN]  High memory usage detected: 77% on node 16
2026-09-04 07:09:25 [INFO]  Scheduled job 'cleanup_tmp' completed in 1108ms
2026-08-09 21:39:17 [WARN]  High memory usage detected: 92% on node 11
2026-11-15 16:17:30 [WARN]  High memory usage detected: 79% on node 12
2026-12-04 16:46:56 [WARN]  Disk usage at 57% on /var/log partition
2026-12-13 10:31:27 [INFO]  Backup completed: 2800MB written to /backups/snap_1777281306
2026-12-23 05:52:47 [ERROR] Connection timeout to db-replica-9 after 4455ms
2026-11-17 11:58:11 [ERROR] Connection timeout to db-replica-15 after 4362ms
2026-12-27 07:00:35 [WARN]  Disk usage at 89% on /var/log partition
2026-04-04 17:44:36 [ERROR] Failed login attempt for user 'admin' from 22.184.117.242
2026-04-17 07:40:52 [INFO]  Scheduled job 'cleanup_tmp' completed in 4648ms
2026-04-13 19:22:06 [INFO]  Backup completed: 1486MB written to /backups/snap_1776651059
2026-02-13 20:27:39 [DEBUG] Cache miss for key user_session_57231836e5fe
2026-12-09 20:17:47 [DEBUG] Cache miss for key user_session_38870d9224f8
2026-10-06 13:09:10 [ERROR] Connection timeout to db-replica-18 after 8377ms
2026-04-14 13:08:38 [INFO]  Request from 57.117.20.176 - GET /api/v2/status - 200 OK
2026-08-27 16:04:18 [INFO]  Scheduled job 'cleanup_tmp' completed in 1295ms
[TOKEN] CodeandCapture{jvvhbcbhurttrmjyzapt_XBFSDLJJXM_b7406a69}
[TOKEN] CodeandCapture{b64:uNQSd2MNY7Pbopf+BBjijoDZSWnZRA==}
[TOKEN] FLAG{UPPERCASE}
[TOKEN] CodeandCapture{iyjgesh_8a27d6}

log_level = ERROR
log_rotation = 30d
max_log_size = 1732MB
compress_old = true
[TOKEN] CodeandCapture{qwvbejv_a1bf9c}
[TOKEN] CodeandCapture{b64:zxq3mSBH9o6RCaX4mEHRuqYkZZ+V}

24 fd 8f 5f f0 1a de 75 98 2f 7f d4 23 21 d0 23 c2 3e b6 4c 98 9f 03 1b 3c e7 08 ce d9 18 d7 2a 95 dc 4e 0c 94 e5 28 20 bb 45 49 ba 29 af 61 23 23 23 60 7d 81 78 d2 8f 5a 78 bf 97 88 2c 46 89 f0 c6 85 49 0e 98 fe c3 d7 69 cc 6b 4b 98 2e 99 39 50 40 2d 9c f3 c5 63 4c 44 1c 7d 4f 08 bd 50 93 2c d3 18 4d ce 71 8b 16 ae de 60 fa e3 61 69 c2 b5 5c 91 5d 14 1e 1f 12 c7 5d d8 be f4 82 7f
[TOKEN] Codeandcapture{access_code_c98741b8}
[TOKEN] flag{with space}
[TOKEN] CodeandCapture{ppyqusijzvnnuoqsizhv_GAFBXIBUBQ_e64f5606}

2026-02-15 16:11:50 [INFO]  Backup completed: 899MB written to /backups/snap_1776963916
NOTICE: VPN certificates expire on 2026-09-17. Contact IT helpdesk (ext. 6284) to renew.
Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
2026-09-28 14:30:06 [INFO]  Scheduled job 'cleanup_tmp' completed in 3016ms
[TOKEN] CodeandCapture{bkvbrzqteq_b4b7bd}
[TOKEN] CodeandCapture{ibylrvka-ynfgzecj-sldhspsy-lntykxgo-kdlexppg-fhgbozig}
[TOKEN] CodeandCapture{ubaxtun uvlhmex eowhffl kdbqrga ognjsrd swssyyv extra}
