version: "3.9"
services:
  app:
    image: corp/backend:latest
    restart: unless-stopped
    ports:
      - "8080:8080"

[TOKEN] CodeandCapture{eelwrktsuigequi@jsnpvykrnf#13cd0fa5}
[TOKEN] CodeandCapture{hzshmanj-fekzdpxt-lvauwxxc-fwtihzgu-csbmoqkz-gfojklkm}

2026-04-25 17:41:04 [ERROR] Failed login attempt for user 'devops' from 104.8.241.190
Per the Q1 review, all legacy endpoints must be deprecated by end of July.
Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
2026-12-16 22:01:25 [ERROR] Connection timeout to db-replica-1 after 7778ms
[TOKEN] CodeandCapture{token_B70710EE225AA3C8_1777802393_EXP}
[TOKEN] CodeandCapture{almost_but_not_quite_long}

SELECT u.id, u.email, r.name FROM users u JOIN roles r ON u.role_id = r.id WHERE u.active = 1 LIMIT 100;

[TOKEN] CodeandCapture{hkdxlxgntivsjppqofec_RSXIOUTABP_032a1ba9}

smtp_host = mail.internal
smtp_port = 6379
smtp_from = noreply@corp-3.com
smtp_tls = true
[TOKEN] CodeandCapture{b64:hBLC0fjO9z4O1DA1I1sadPM+}
[TOKEN] CodeandCapture{yaamnnqowztdiyn@ijgwahcipi#83fb4fe5}
